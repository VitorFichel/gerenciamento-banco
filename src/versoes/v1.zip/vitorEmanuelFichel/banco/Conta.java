package pedroSantosNeto.banco;
import java.util.ArrayList;


public class Conta {

	private int numero;
	private double saldo;
	private Pessoa dono;
    private ArrayList<String> extrato = new ArrayList<>();
	
	public Conta(int n, Pessoa p) {
		if (n > 0) { 
		  numero = n;	
		  dono = p;
		} 
	}
	
	public Pessoa getDono() {
		return dono;
	}
	
	public int getNumero() {
		return numero;
	}
	
	public double getSaldo() {
		return saldo;
	}
	
	public void credito(double valor) {
		if (valor > 0) {
		    saldo = saldo + valor;
            extrato.add("Crédito: +"+valor);
		}
	}
	
	public String getExtrato() {

        String resultado = "Extrato da conta:\n";

        for(String valores: extrato){
            resultado += valores + "\n"; 
            }
        
		return resultado;
	}
	
	public void debito(double valor) {
		if (valor > 0 && valor <= saldo) {
		    saldo = saldo - valor;
            extrato.add("Débito: -"+valor);
		} else {
			System.out.println("Valor debitado invalido.");
		}
	}
}
