package banco;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;

import static org.junit.jupiter.api.Assertions.*;



public class ContaTest {

    Pessoa p1;
    Conta c1;

    @BeforeEach
    public void setUpConta() {
        p1 = new Pessoa(1, "Pedro");
        c1 = new Conta(1, p1);
    }

    @Test
    public void testConta() {
        assertEquals(p1, c1.getDono());
		assertEquals(1, c1.getNumero());
        assertEquals(0.0, c1.getSaldo());
    }

    @Test
    public void testCredito() {
        c1.credito(100);
        assertEquals(100.0, c1.getSaldo());
    }

	@Test
    public void testCreditoNegtivo() {
        c1.credito(-100);
        assertEquals(0.0, c1.getSaldo());
    }

    @Test
    public void testDebito() {
        c1.credito(100);
        c1.debito(30);
        assertEquals(70.0, c1.getSaldo());
    }

	@Test
    public void testDebitoMaior() {
        c1.credito(100);
        c1.debito(300);
        assertEquals(100.0, c1.getSaldo());
    }

	@Test
	public void testExtrato(){
		c1.credito(100);
		c1.debito(50);
		String extrato = c1.getExtrato();
		assertTrue(extrato.contains("Crédito: +100.0"));
		assertTrue(extrato.contains("Débito: -50.0"));

	}
}