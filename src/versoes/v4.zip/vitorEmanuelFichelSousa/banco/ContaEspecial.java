package pedroSantosNeto.banco;

public class ContaEspecial extends Conta {

	private double limite;

	public ContaEspecial(int n, Pessoa p, double l) {
		super(n, p);
		limite = l;
	}

	public void debito(double valor) {
		if (valor > 0 && valor <= saldo + limite) {
		   saldo = saldo - valor;
		   extrato.adicionarOperacao(null, getNumero(), valor, saldo, "Debito");
		} else {
			System.out.println("Valor debitado invalido.");
		}
	}	
}
