package pedroSantosNeto.banco;

public class ListaDeContas implements EstruturaDeDadosDeConta {

	private Conta conta = null;
	private ListaDeContas prox = null;
	
	public boolean inserir(Conta c) {

		Conta outra = pesquisar(c.getNumero());
		if (outra != null) {
			return false;
		}
		if (prox == null) {
			ListaDeContas novo = new ListaDeContas();
			conta = c;
			novo.conta = null;
			novo.prox = null;
			prox = novo;
			return true;
		} else {
			return prox.inserir(c);
		}
	}
	
	public Conta pesquisar(int n) {
		if (conta == null) {
			return null;
		}
		if (conta.getNumero() == n) {
			return conta;
		} else {
			return prox.pesquisar(n);
		}
	}
}
