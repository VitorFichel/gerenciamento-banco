package pedroSantosNeto.banco;

public interface EstruturaDeDadosDeConta {

	public boolean inserir(Conta c);
	public Conta pesquisar(int n);

}
