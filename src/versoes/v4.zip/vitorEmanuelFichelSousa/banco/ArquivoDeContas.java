package pedroSantosNeto.banco;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class ArquivoDeContas implements EstruturaDeDadosDeConta {
    
    private final String NOME_ARQUIVO = "contas.txt";
    private final String SEPARADOR = ";";
    
 
    public ArquivoDeContas() {
        try {
            File arquivo = new File(NOME_ARQUIVO);
            if (!arquivo.exists()) {
                arquivo.createNewFile();
            }
        } catch (IOException e) {
            System.err.println("Erro ao criar arquivo: " + e.getMessage());
        }
    }
    
    @Override
    public boolean inserir(Conta c) {

        if (pesquisar(c.getNumero()) != null) {
            return false;
        }
        
        ArrayList<Conta> contas = lerTodasContas();
        contas.add(c);
        return salvarTodasContas(contas);
    }
    
    @Override
    public Conta pesquisar(int n) {
        try (Scanner sc = new Scanner(new FileReader(NOME_ARQUIVO))) {
            while (sc.hasNextLine()) {
                String linha = sc.nextLine();
                String[] dados = linha.split(SEPARADOR);
                
                if (dados.length >= 5) {
                    int numero = Integer.parseInt(dados[0]);
                    if (numero == n) {
                        return criarContaDoArquivo(dados);
                    }
                }
            }
        } catch (FileNotFoundException e) {

            return null;
        } catch (Exception e) {
            System.err.println("Erro ao pesquisar conta: " + e.getMessage());
        }
        return null;
    }
    

    private ArrayList<Conta> lerTodasContas() {
        ArrayList<Conta> contas = new ArrayList<>();
        
        try (Scanner sc = new Scanner(new FileReader(NOME_ARQUIVO))) {
            while (sc.hasNextLine()) {
                String linha = sc.nextLine();
                String[] dados = linha.split(SEPARADOR);
                
                if (dados.length >= 5) {
                    Conta conta = criarContaDoArquivo(dados);
                    if (conta != null) {
                        contas.add(conta);
                    }
                }
            }
        } catch (FileNotFoundException e) {

        } catch (Exception e) {
            System.err.println("Erro ao ler contas: " + e.getMessage());
        }
        
        return contas;
    }
    

    private boolean salvarTodasContas(ArrayList<Conta> contas) {
        try (FileWriter fw = new FileWriter(NOME_ARQUIVO, false);  // false para sobrescrever o arquivo
             PrintWriter pw = new PrintWriter(fw)) {
            
            for (Conta c : contas) {

                String linha = c.getNumero() + SEPARADOR + 
                              c.getSaldo() + SEPARADOR + 
                              c.getClass().getSimpleName() + SEPARADOR + 
                              c.getDono().getCpf() + SEPARADOR + 
                              c.getDono().getNome();
                

                if (c instanceof ContaEspecial) {
                    ContaEspecial ce = (ContaEspecial) c;

                    linha += SEPARADOR + "200.0";
                } else if (c instanceof ContaImposto) {
                    ContaImposto ci = (ContaImposto) c;

                    linha += SEPARADOR + "0.01";
                }
                
                pw.println(linha);
            }
            return true;
            
        } catch (IOException e) {
            System.err.println("Erro ao salvar contas: " + e.getMessage());
            return false;
        }
    }
    

    private Conta criarContaDoArquivo(String[] dados) {
        try {
            int numero = Integer.parseInt(dados[0]);
            double saldo = Double.parseDouble(dados[1]);
            String tipo = dados[2];
            int cpf = Integer.parseInt(dados[3]);
            String nome = dados[4];
            
            Pessoa pessoa = new Pessoa(cpf, nome);
            Conta conta = null;
            
            switch (tipo) {
                case "ContaComum":
                    conta = new ContaComum(numero, pessoa);
                    break;
                case "Poupanca":
                    conta = new Poupanca(numero, pessoa);
                    break;
                case "ContaEspecial":
                    double limite = 200.0;
                    if (dados.length >= 6) {
                        limite = Double.parseDouble(dados[5]);
                    }
                    conta = new ContaEspecial(numero, pessoa, limite);
                    break;
                case "ContaImposto":
                    double imposto = 0.01;
                    if (dados.length >= 6) {
                        imposto = Double.parseDouble(dados[5]);
                    }
                    conta = new ContaImposto(numero, pessoa, imposto);
                    break;
                default:
                    conta = new ContaComum(numero, pessoa);
            }
            
            if (conta != null && saldo != 0) {
                conta.credito(saldo);
            }
            
            return conta;
            
        } catch (Exception e) {
            System.err.println("Erro ao criar conta do arquivo: " + e.getMessage());
            return null;
        }
    }
    

    public boolean remover(int numero) {
        ArrayList<Conta> contas = lerTodasContas();
        boolean removido = false;
        
        for (int i = 0; i < contas.size(); i++) {
            if (contas.get(i).getNumero() == numero) {
                contas.remove(i);
                removido = true;
                break;
            }
        }
        
        if (removido) {
            return salvarTodasContas(contas);
        }
        
        return false;
    }
    

    public void listarTodasContas() {
        try (Scanner sc = new Scanner(new FileReader(NOME_ARQUIVO))) {
            System.out.println("=== CONTAS NO ARQUIVO ===");
            while (sc.hasNextLine()) {
                String linha = sc.nextLine();
                System.out.println(linha);
            }
            System.out.println("========================");
        } catch (FileNotFoundException e) {
            System.out.println("Nenhuma conta encontrada - arquivo não existe.");
        } catch (Exception e) {
            System.err.println("Erro ao listar contas: " + e.getMessage());
        }
    }
}