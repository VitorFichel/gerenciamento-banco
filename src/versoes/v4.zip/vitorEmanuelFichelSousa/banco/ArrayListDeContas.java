package pedroSantosNeto.banco;

import java.util.ArrayList;

public class ArrayListDeContas implements EstruturaDeDadosDeConta {
	
	private ArrayList<Conta> lista = new ArrayList<Conta>();

	public boolean inserir(Conta c) {
		Conta outra = pesquisar(c.getNumero());
		if (outra == null) {
		   lista.add(c);
		   return true;
		}
		return false;
	}

	public Conta pesquisar(int n) {
		for (Conta conta : lista) {
			if (conta.getNumero() == n) {
				return conta;
			}
		}
		return null;
	}
}
