package pedroSantosNeto.banco;

public class VetorDeContas implements EstruturaDeDadosDeConta{

	private Conta[] contas = new Conta[50];
	private int pos = 0;
	
	public boolean inserir(Conta c) {
		Conta outra = pesquisar(c.getNumero());
		if (outra == null) {
		  contas[pos++] = c;
		  return true;
		}
		return false;
	}

	public Conta pesquisar(int n) {
		for (int i = 0; i < pos; i++) {
			if (contas[i].getNumero() == n) {
				return contas[i];
			}
		}
		return null;
	}
}
