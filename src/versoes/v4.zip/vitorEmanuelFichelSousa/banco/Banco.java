package pedroSantosNeto.banco;

public class Banco {
	
	private EstruturaDeDadosDeConta contas;
	
	public Banco(EstruturaDeDadosDeConta estrutura) {
		contas = estrutura;		
	}
	
	public boolean inserir(Conta c) {
		return contas.inserir(c);
	}
	
	public void juros(int n, double t) {
		Conta c = contas.pesquisar(n);
		if (c != null && c instanceof Poupanca) {
			((Poupanca) c).rendeJuros(t);
		}
	}

	public void deposito(int n, double v) {
		Conta c = contas.pesquisar(n);
		if (c != null) {
		  c.credito(v);
		}
	}
		
	public void saque(int n, double v) {
		Conta c = contas.pesquisar(n);
		if (c != null) {
		  c.debito(v);
		}
	}
	
	public double saldo(int n) {
		Conta c = contas.pesquisar(n);
		if (c != null) {
		  return c.getSaldo();
		} else {
		  return -9999999;
		}
	}
	
	public String extrato(int n) {
		Conta c = contas.pesquisar(n);
		if (c != null) {
		  return c.getExtrato();
		}
		return "";
	}
	
	public void transferencia() {	
	}
}
