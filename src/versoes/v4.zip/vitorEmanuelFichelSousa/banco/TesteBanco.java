package pedroSantosNeto.banco;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class TesteBanco {

	@Test
	void testarCadastroDePoupancas() {
		Pessoa p1 = new Pessoa(1, "Pedro");
		Pessoa p2 = new Pessoa(2, "Raimundo");
		
		Conta c1 = new Poupanca(1, p1);
		Conta c2 = new Poupanca(2, p2);
		
		EstruturaDeDadosDeConta estr = new VetorDeContas();
		Banco b = new Banco(estr);
		
		assertTrue(b.inserir(c1));
		assertTrue(b.inserir(c2));
		
		assertFalse(b.inserir(c1));
		
		assertEquals(0, b.saldo(1));
		assertEquals(0, b.saldo(2));
		assertEquals(-9999999, b.saldo(3));
	}
	
	@Test
	void testarCadastroDeContas() {
		Pessoa p1 = new Pessoa(1, "Pedro");
		Pessoa p2 = new Pessoa(2, "Raimundo");
		
		Conta c1 = new ContaComum(1, p1);
		Conta c2 = new ContaComum(2, p2);
		
		EstruturaDeDadosDeConta estr = new ArrayListDeContas();
		Banco b = new Banco(estr);
		
		assertTrue(b.inserir(c1));
		assertTrue(b.inserir(c2));
		
		assertFalse(b.inserir(c1));
		
		assertEquals(0, b.saldo(1));
		assertEquals(0, b.saldo(2));
		assertEquals(-9999999, b.saldo(3));
	}
	
	@Test
	void testarCreditoDebitoDeContas() {
		Pessoa p1 = new Pessoa(1, "Pedro");
		Conta c1 = new ContaComum(1, p1);
		
		EstruturaDeDadosDeConta estr = new ListaDeContas();
		Banco b = new Banco(estr);
		
		b.inserir(c1);
		b.deposito(1, 100);
		assertEquals(100, b.saldo(1));
		b.saque(1, 99);
		assertEquals(1, b.saldo(1));
		b.saque(1, 2);
		assertEquals(1, b.saldo(1));
		System.out.println(b.extrato(1));
		assertEquals("\nConta: 1. Credito: 100.0. Saldo: 100.0\n" + 
				"Conta: 1. Debito: 99.0. Saldo: 1.0", b.extrato(1));
		
		b.deposito(3, 100);
		assertEquals(-9999999, b.saldo(3));
		b.saque(3, 100);
		assertEquals(-9999999, b.saldo(3));
		assertEquals("", b.extrato(3));
	}
	
	@Test
	void testarCreditoDebitoDePoupancas() {
		Pessoa p1 = new Pessoa(1, "Pedro");
		Conta c1 = new Poupanca(1, p1);		

		EstruturaDeDadosDeConta estr = new ListaDeContas();
		Banco b = new Banco(estr);
		
		b.inserir(c1);
		b.deposito(1, 100);
		assertEquals(100, b.saldo(1));
		b.saque(1, 99);
		assertEquals(1, b.saldo(1));
		b.saque(1, 2);
		assertEquals(1, b.saldo(1));
		System.out.println(b.extrato(1));
		assertEquals("\nConta: 1. Credito: 100.0. Saldo: 100.0\n" + 
				"Conta: 1. Debito: 99.0. Saldo: 1.0", b.extrato(1));
		
		b.deposito(3, 100);
		assertEquals(-9999999, b.saldo(3));
		b.saque(3, 100);
		assertEquals(-9999999, b.saldo(3));
		assertEquals("", b.extrato(3));
	}
	
	@Test
	void testarJurosPoupanca() {
		Pessoa p1 = new Pessoa(1, "Pedro");
		Conta c1 = new Poupanca(1, p1);	
		Pessoa p2 = new Pessoa(2, "Raimundo");
		Conta c2 = new ContaComum(2, p2);

		EstruturaDeDadosDeConta estr = new ListaDeContas();
		Banco b = new Banco(estr);
		
		b.inserir(c1);
		b.deposito(1, 100);
		assertEquals(100, b.saldo(1));
		b.juros(1, 0.01);
		assertEquals(101, b.saldo(1));
		
		b.inserir(c2);
		b.deposito(2, 100);
		assertEquals(100, b.saldo(2));
		b.juros(2, 0.01);
		assertEquals(100, b.saldo(2));
		
		b.deposito(3, 100);
		assertEquals(-9999999, b.saldo(3));
		b.juros(3, 0.01);
		assertEquals(-9999999, b.saldo(3));
	}

	@Test
	void testarContaImposto() {
		Pessoa p1 = new Pessoa(1, "Pedro");
		Conta c1 = new ContaImposto(1, p1, 0.01);	

		EstruturaDeDadosDeConta estr = new ListaDeContas();
		Banco b = new Banco(estr);
		
		b.inserir(c1);
		b.deposito(1, 100);
		assertEquals(100, b.saldo(1));
		b.saque(1, 80);
		assertEquals(19.20, b.saldo(1), 0.0001);
	}
	

	@Test
	void testarContaEspecial() {
		Pessoa p1 = new Pessoa(1, "Pedro");
		Conta c1 = new ContaEspecial(1, p1, 200);	

		EstruturaDeDadosDeConta estr = new ListaDeContas();
		Banco b = new Banco(estr);
		
		b.inserir(c1);
		b.deposito(1, 100);
		assertEquals(100, b.saldo(1));
		b.saque(1, 200);
		assertEquals(-100, b.saldo(1), 0.0001);
		b.saque(1, 100);
		assertEquals(-200, b.saldo(1), 0.0001);
		b.saque(1, 0.01);
		assertEquals(-200, b.saldo(1), 0.0001);
	}

}
