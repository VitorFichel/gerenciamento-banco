package pedroSantosNeto.banco;

public class Banco {
	
	private Conta[] contas = new Conta[50];
	private int pos = 0;
	
	public void inserir(Conta c) {
		contas[pos++] = c;
	}

	public void deposito(int n, double v) {
		for (int i = 0; i < pos; i++) {
			if (contas[i].getNumero() == n) {
				contas[i].credito(v);
			}
		}
	}
	
	public void saque(int n, double v) {
		for (int i = 0; i < pos; i++) {
			if (contas[i].getNumero() == n) {
				contas[i].debito(v);
			}
		}
	}
	
	public double saldo(int n) {
		for (int i = 0; i < pos; i++) {
			if (contas[i].getNumero() == n) {
				return contas[i].getSaldo();
			}
		}
		return -9999999;
	}
	
	public String extrato(int n) {
		for (int i = 0; i < pos; i++) {
			if (contas[i].getNumero() == n) {
				return contas[i].getExtrato();
			}
		}
		return "";
	}
	
	public void transferencia(int env, int receb, double v) {
		for(int i=0; i<pos; i++){
			if(contas[i].getNumero() == env){
				for(int j=0; j<pos; j++){
					if(contas[j].getNumero() == receb){
						if(v <= contas[i].getSaldo()){
							contas[i].debito(v);
							contas[j].credito(v);
						}
						else{
							System.err.println("saldo insuficiente.");
						}
					}
					else{
						System.err.println("Número da conta destinatário não encontrada");
					}
				}
				
			}
			else{
				System.err.println("Número da conta remetente não encontrada");
			}
		}	
	}
}
